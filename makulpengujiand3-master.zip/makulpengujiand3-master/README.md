makulpengujiand3
================
Tugas matakuliah pengujian D3:
Berikut adalah source code yang berisi program kalkulator sederhana dalam bahasa C#.
Silakan kalian membuat unit test untuk masing2 fungsi.
Kemudian buat coded UI test untuk interface dari kalkulator tersebut.
Silakan buat unit test dan coded ui testnya kemudian upload ke github.
Berikan link github kalian ke saya pada pertemuan selanjutnya (kamis).

Terima kasih,

Hint: Jika kalian membuatnya selengkap mungkin, itu akan membantu kalian saat UAS nanti :)